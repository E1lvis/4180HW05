//HW05
//group18_hw05
//Elvis Velasquez, Eduardo Gomez

package com.example.group18_hw05;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    ExecutorService threadPool;
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SeekBar bar = findViewById(R.id.seekBar);
        bar.setMax(20);

        TextView complexityNumber = findViewById(R.id.textViewComplexityNumber);
        TextView timesRun = findViewById(R.id.runAmount);
        TextView average = findViewById(R.id.computedAvg);
        //setting to initial value of 0
        complexityNumber.setText(String.valueOf(bar.getProgress()));

        Button button = findViewById(R.id.buttonGenerate);

        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setMax(20);

        threadPool = Executors.newFixedThreadPool(2);

        //list view and adapter set up
        ListView list = findViewById(R.id.listView);
        ArrayList<String> arrayF = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, arrayF);
        list.setAdapter(adapter);


        //handler set up
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                switch (message.what){
                    case work.Working:
                        //This string is the progress of the runtime as it happens
                        //can probably just that to set the current progress up top
                        int receivedProgress = (int) message.obj;
                        progressBar.setProgress(receivedProgress);
                        timesRun.setText(String.valueOf(receivedProgress) + "/" + String.valueOf(bar.getProgress()));


                        //Log.d("Tag", "handleMessage: " + receivedProgress);
                        //add every new number to main thread array, then notify the adapter that there is new data
                        arrayF.add(message.getData().getStringArrayList("key").get(message.getData().getInt("number")));

                        double sum = 0.0;
                        double avg = 0.0;

                        // calculate average for each number entered into array
                        for (int i = 0; i < arrayF.size() - 1; ++i){
                            sum += Double.valueOf(arrayF.get(i));
                        }

                        avg = sum / arrayF.size();

                        // set average on TextView
                        average.setText(String.valueOf(avg));
                        
                        adapter.notifyDataSetChanged();
                        break;

                    //I dont think we need this, i jjust made it bc i went off in another direction by mistake woops, delte if not used
                    case work.Done:
                        if(message.getData().getStringArrayList("key") != null){



                        }
                }



                return false;
            }
        });





        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                complexityNumber.setText(String.valueOf(i) + " Times");

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //Thread execution should be done in the button handler
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                threadPool.execute(new work(bar.getProgress()));


            }
        });
    }

    class work implements Runnable{
        //Im not sure hgowq to send a double array list some im converting them to strings for now
        ArrayList<String> rList = new ArrayList<>();
        int runAmount;
        //return this in message to notify of current progess. return as string progess/runamount

        //state variables
        static final int Working = 0x00;
        static final int Done = 0x01;

        int progess;
        public work(int progress) {
            runAmount = progress;
        }


        //dont change i here, im sending i as the index of the added number of the array to set in the main thread array, for setting the progess you could do I+1 in the handler when setting text
        @Override
        public void run() {
            for(int i = 0; i < runAmount; i++){
                //Log.d("TAG", "run: " + i);
                rList.add(String.valueOf(HeavyWork.getNumber()));

                //sending current progress in each run
                Message currentProgress = new Message();
                currentProgress.what = Working;

                //add string to message instance as obj
                currentProgress.obj = i + 1;

                Bundle bundle = new Bundle();
                bundle.putInt("number", i);
                bundle.putStringArrayList("key",  rList);
                currentProgress.setData(bundle);

                //send to handler
                handler.sendMessage(currentProgress);


            }

            //stuff below probably isnt needed either, delete if you not used
            //After runs are complete send array to main thread
            Message completeList = new Message();
            completeList.what = Done;
            //will send array as bundle
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("key",  rList);
            completeList.setData(bundle);
            handler.sendMessage(completeList);

        }



    }
}